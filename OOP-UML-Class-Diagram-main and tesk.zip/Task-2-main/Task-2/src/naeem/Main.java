package naeem;

/*
  Name : Naeem Khan
  ID : 2012020105
  Section : C
  Email : cse_2012020105@lus.ac.bd
  Date : 08-08-2021
 */

public class Main {

    public static void main(String[] args) {

        Student stOne = new Student();
        Student sttwo = new Student("Naeem Khan");
        Student stThree = new Student(2012020105);

        stOne.display();

    }
}

