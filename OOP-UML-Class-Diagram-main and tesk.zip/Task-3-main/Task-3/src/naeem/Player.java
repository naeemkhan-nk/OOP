package naeem;

public class Player {
    String playerName;
    int jerseyNumber;

    Player(String playerName, int jerseyNumber)
    {
        this.playerName = playerName;
        this.jerseyNumber = jerseyNumber;
    }
}
/*
    Name : Naeem Khan
    ID : 2012020105
    Section : C
    bath : 53
    Email : cse_2012020105@lus.ac.bd
    Date : 11-09-2021
    */
