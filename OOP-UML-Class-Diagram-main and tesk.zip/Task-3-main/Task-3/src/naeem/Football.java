package naeem;

public class Football extends Sports{
    Football()
    {
        super();
        System.out.println("Football class called");
    }
}
/*
    Name : Naeem Khan
    ID : 2012020105
    Section : C
    bath : 53
    Email : cse_2012020105@lus.ac.bd
    Date : 11-09-2021
    */
