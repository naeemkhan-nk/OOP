package naeem;

public class Main {

    public static void main(String[] args) {
        System.out.println("");
        Player player = new Player("Shakib", 75);
        Cricket cricket = new Cricket("International match", 20, player);

        cricket.display();
        Football football = new Football();

    }
}
/*
    Name : Naeem Khan
    ID : 2012020105
    Section : C
    bath : 53
    Email : cse_2012020105@lus.ac.bd
    Date : 11-09-2021
    */
