package naeem;
/*
 *Name : Naeem Khan
 * ID : 2012020105
 * Section : C
 * Email : cse_2012020105
 * Data : 15-07-2021

 */
public class Info {
    String name = "Naeem Khan";
    int id = 2012020105;
}
