package naeem;

/*
 *Name : Naeem Khan
 * ID : 2012020105
 * Section : C
 * Email : cse_2012020105
 * Data : 15-07-2021

 */
public class Hobby {
    String hobbyName = "Programming";
}
